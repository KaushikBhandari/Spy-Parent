package com.gcq.androidapp.SPYParent.interfaces;

public interface OnLanguageSelectionListener {
	void onLanguageSelection(String language);
}
