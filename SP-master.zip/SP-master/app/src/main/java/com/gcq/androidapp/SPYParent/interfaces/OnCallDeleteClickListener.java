package com.gcq.androidapp.SPYParent.interfaces;

public interface OnCallDeleteClickListener {
    //no longer used because we used the swiping instead of clicking the delete button
    //void onCallDeleteClick(Call call);

}
