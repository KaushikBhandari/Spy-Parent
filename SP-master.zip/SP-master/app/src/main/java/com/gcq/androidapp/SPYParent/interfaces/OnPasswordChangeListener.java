package com.gcq.androidapp.SPYParent.interfaces;

public interface OnPasswordChangeListener {
	void onPasswordChange(String newPassword);
}
