package com.gcq.androidapp.SPYParent.interfaces;

public interface OnPasswordValidationListener {
	void onValidationOk();
}
