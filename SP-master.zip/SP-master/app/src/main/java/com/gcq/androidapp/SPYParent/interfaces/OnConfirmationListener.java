package com.gcq.androidapp.SPYParent.interfaces;

public interface OnConfirmationListener {
    void onConfirm();

    void onConfirmationCancel();
}
