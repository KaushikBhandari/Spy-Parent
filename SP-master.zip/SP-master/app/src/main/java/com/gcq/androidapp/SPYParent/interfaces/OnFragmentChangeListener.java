package com.gcq.androidapp.SPYParent.interfaces;

public interface OnFragmentChangeListener {
    void onFragmentChange(int id);
}
