package com.gcq.androidapp.SPYParent.interfaces;

public interface OnGeoFenceSettingListener {
    void onGeoFenceSet(String geoFenceCenter, double geoFenceDiameter);
}
