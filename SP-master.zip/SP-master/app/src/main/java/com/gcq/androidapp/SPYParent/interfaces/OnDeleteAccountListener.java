package com.gcq.androidapp.SPYParent.interfaces;

public interface OnDeleteAccountListener {
	void onDeleteAccount(String password);
}
