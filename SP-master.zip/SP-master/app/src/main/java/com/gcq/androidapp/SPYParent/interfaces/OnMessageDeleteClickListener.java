package com.gcq.androidapp.SPYParent.interfaces;

public interface OnMessageDeleteClickListener {
    //used swiping instead of a button
    //void onMessageDeleteClick(Message message);
}
