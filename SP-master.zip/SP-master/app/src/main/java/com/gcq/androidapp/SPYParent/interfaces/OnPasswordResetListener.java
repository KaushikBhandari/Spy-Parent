package com.gcq.androidapp.SPYParent.interfaces;

public interface OnPasswordResetListener {
    void onOkClicked(String email);

    void onCancelClicked();
}
