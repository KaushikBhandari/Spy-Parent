package com.gcq.androidapp.SPYParent.models;

public class Parent extends User {
	public Parent() {
	}
	
	public Parent(String name, String email) {
		super(name, email);
	}
}
