package com.gcq.androidapp.SPYParent.interfaces;

public interface OnGoogleChildSignUp {

    void onModeSelected(String parentEmail);
}
