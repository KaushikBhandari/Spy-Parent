package com.gcq.androidapp.SPYParent.interfaces;

public interface OnContactClickListener {

    void onCallClick(String contactNumber);

    void onMessageClick(String contactNumber);
}
