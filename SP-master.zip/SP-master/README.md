# SP
Basically SP stands for SPY PARENT ..so basically this is one parental controll application.
I have used 100% java in it and for backend firebase 
features inclueds:
-blocking apps
-monitoring calls,messages & contacts
-live location tracking,geofencing
-phone off
